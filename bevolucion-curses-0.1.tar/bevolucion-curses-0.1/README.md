bevolucion
==========

API de células que muestra la reproducción de una población entre los más aptos con el fin de evolucionar a tener un gen elite de referencia, se pueden cargar los genes conocidos en formato FASTA, como Ecoli u otros para simular comportamiento de poblaciones
